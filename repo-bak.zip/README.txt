﻿repo-bak/ README
----------------
This folder contains timestamped .bak copies of files changed on 2025-08-19 during the backend URL update.
Example files:
  - index.html.20250819131618.bak
  - jessica.html.20250819131618.bak
  - travis.html.20250819131618.bak
  - <other .bak files>

Do not remove unless you intentionally want to delete the backups.
To restore, copy the chosen .bak file back to the repo root and review before committing.
